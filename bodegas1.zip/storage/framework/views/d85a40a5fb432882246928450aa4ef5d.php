<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title', 'Login - Inventario'); ?></title>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body class="ui-shell flex min-h-screen items-center justify-center px-4 py-8">

    <?php echo $__env->yieldContent('content'); ?>

</body>
</html>
<?php /**PATH C:\Users\EDSONG-PC\OneDrive - Grupo Soluciones en Conectividad S.A,\Documentos\GitHub\Edson-REP\resources\views/layouts/guest.blade.php ENDPATH**/ ?>