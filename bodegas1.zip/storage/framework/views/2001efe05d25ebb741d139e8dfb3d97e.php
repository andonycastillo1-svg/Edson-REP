<?php $__env->startSection('title', 'Solicitud #' . $operacion->id); ?>

<?php $__env->startSection('content'); ?>
<?php
  $routePrefix = auth()->user()->role_id == 2 ? 'operador' : 'admin';

  if ($operacion->estado === 'PENDIENTE') {
      $badgeClass = 'badge-pendiente';
  } elseif ($operacion->estado === 'APROBADO') {
      $badgeClass = 'badge-aprobado';
  } elseif ($operacion->estado === 'RECHAZADO') {
      $badgeClass = 'badge-rechazado';
  } else {
      $badgeClass = 'badge-default';
  }
?>

<style>
  .show-page {
    width: 100%;
    min-height: calc(100vh - 64px);
    background: #f8fafc;
    padding: 18px 14px;
  }

  .show-container {
    width: 100%;
    max-width: 920px;
    margin: 0 auto;
  }

  .show-header {
    background: #ffffff;
    border: 1px solid #dbe3ea;
    border-radius: 14px;
    box-shadow: 0 1px 2px rgba(15, 23, 42, 0.04);
    padding: 14px 16px;
    margin-bottom: 12px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    flex-wrap: wrap;
  }

  .show-title {
    margin: 0;
    font-size: 22px;
    line-height: 1.1;
    font-weight: 800;
    color: #0f172a;
  }

  .show-subtitle {
    margin-top: 5px;
    font-size: 13px;
    color: #64748b;
  }

  .show-actions {
    display: flex;
    align-items: center;
    gap: 8px;
    flex-wrap: wrap;
  }

  .btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    height: 32px;
    padding: 0 13px;
    border-radius: 8px;
    font-size: 12px;
    font-weight: 800;
    text-decoration: none !important;
    border: 1px solid transparent;
    cursor: pointer;
    line-height: 1;
  }

  .btn-dark {
    background: #0f172a !important;
    color: #ffffff !important;
    border-color: #0f172a !important;
  }

  .btn-blue {
    background: #2563eb !important;
    color: #ffffff !important;
    border-color: #2563eb !important;
  }

  .btn-white {
    background: #ffffff !important;
    color: #334155 !important;
    border-color: #cbd5e1 !important;
  }

  .btn-green {
    background: #059669 !important;
    color: #ffffff !important;
    border-color: #059669 !important;
  }

  .btn-red {
    background: #dc2626 !important;
    color: #ffffff !important;
    border-color: #dc2626 !important;
  }

  .alert {
    margin-bottom: 12px;
    border-radius: 12px;
    padding: 10px 14px;
    font-size: 13px;
    font-weight: 600;
  }

  .alert-ok {
    border: 1px solid #bbf7d0;
    background: #ecfdf5;
    color: #047857;
  }

  .alert-error {
    border: 1px solid #fecaca;
    background: #fef2f2;
    color: #b91c1c;
  }

  .main-card {
    background: #ffffff;
    border: 1px solid #dbe3ea;
    border-radius: 14px;
    box-shadow: 0 1px 2px rgba(15, 23, 42, 0.04);
    overflow: hidden;
  }

  .summary-box {
    padding: 16px;
    border-bottom: 1px solid #e2e8f0;
  }

  .summary-top {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 12px;
    flex-wrap: wrap;
  }

  .route-line {
    font-size: 14px;
    color: #334155;
  }

  .route-line strong {
    color: #0f172a;
  }

  .route-arrow {
    color: #94a3b8;
    margin: 0 6px;
  }

  .meta-line {
    margin-top: 8px;
    font-size: 12px;
    color: #64748b;
  }

  .meta-line strong {
    color: #334155;
  }

  .badge {
    display: inline-flex;
    align-items: center;
    border-radius: 999px;
    padding: 5px 11px;
    font-size: 11px;
    font-weight: 800;
    white-space: nowrap;
  }

  .badge-pendiente {
    background: #fffbeb;
    color: #b45309;
  }

  .badge-aprobado {
    background: #ecfdf5;
    color: #047857;
  }

  .badge-rechazado {
    background: #fef2f2;
    color: #b91c1c;
  }

  .badge-default {
    background: #f1f5f9;
    color: #475569;
  }

  .note-box {
    margin-top: 12px;
    border: 1px solid #dbe3ea;
    background: #f8fafc;
    border-radius: 10px;
    padding: 10px 12px;
    font-size: 13px;
    color: #334155;
  }

  .reject-box {
    margin-top: 12px;
    border: 1px solid #fecaca;
    background: #fef2f2;
    border-radius: 10px;
    padding: 10px 12px;
    font-size: 13px;
    color: #991b1b;
  }

  .section-title {
    padding: 12px 16px;
    background: #f8fafc;
    border-bottom: 1px solid #e2e8f0;
    font-size: 13px;
    font-weight: 800;
    color: #0f172a;
    display: flex;
    justify-content: space-between;
    gap: 10px;
  }

  .table-wrap {
    overflow-x: auto;
  }

  .items-table {
    width: 100%;
    min-width: 620px;
    border-collapse: collapse;
    font-size: 12px;
  }

  .items-table thead {
    background: #ffffff;
    border-bottom: 1px solid #e2e8f0;
    color: #64748b;
    text-transform: uppercase;
    font-size: 11px;
    letter-spacing: .03em;
  }

  .items-table th {
    text-align: left;
    font-weight: 800;
    padding: 9px 12px;
  }

  .items-table td {
    padding: 10px 12px;
    border-bottom: 1px solid #eef2f7;
    vertical-align: middle;
    color: #334155;
  }

  .product-code {
    font-weight: 800;
    color: #0f172a;
  }

  .product-name {
    margin-top: 2px;
    font-size: 11px;
    color: #64748b;
  }

  .qty {
    text-align: right;
    font-size: 14px;
    font-weight: 800;
    color: #0f172a;
  }

  .empty-products {
    padding: 24px 12px !important;
    text-align: center;
    color: #64748b !important;
  }

  .decision-box {
    padding: 14px 16px;
    background: #f8fafc;
    border-top: 1px solid #e2e8f0;
  }

  .decision-grid {
    display: flex;
    justify-content: flex-end;
    gap: 10px;
    flex-wrap: wrap;
  }

  .reject-form {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
  }

  .input {
    height: 32px;
    min-width: 260px;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    padding: 0 10px;
    font-size: 12px;
    color: #334155;
    background: #ffffff;
  }

  .input:focus {
    outline: 2px solid #dbeafe;
    border-color: #3b82f6;
  }

  .bottom-actions {
    margin-top: 14px;
    display: flex;
    justify-content: flex-end;
  }

  @media (max-width: 700px) {
    .show-header {
      align-items: stretch;
    }

    .show-actions {
      justify-content: flex-start;
    }

    .decision-grid {
      justify-content: stretch;
    }

    .reject-form,
    .reject-form .input,
    .reject-form button,
    .decision-grid form {
      width: 100%;
    }
  }
</style>

<div class="show-page">
  <div class="show-container">
    <?php if (isset($component)) { $__componentOriginal907d7ba0ef057281d9e83257e5f04480 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal907d7ba0ef057281d9e83257e5f04480 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.internal-navigation','data' => ['backUrl' => route($routePrefix . '.operaciones.traslados.index')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('internal-navigation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['back-url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route($routePrefix . '.operaciones.traslados.index'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal907d7ba0ef057281d9e83257e5f04480)): ?>
<?php $attributes = $__attributesOriginal907d7ba0ef057281d9e83257e5f04480; ?>
<?php unset($__attributesOriginal907d7ba0ef057281d9e83257e5f04480); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal907d7ba0ef057281d9e83257e5f04480)): ?>
<?php $component = $__componentOriginal907d7ba0ef057281d9e83257e5f04480; ?>
<?php unset($__componentOriginal907d7ba0ef057281d9e83257e5f04480); ?>
<?php endif; ?>

    <div class="show-header">
      <div>
        <h1 class="show-title">Solicitud #<?php echo e($operacion->id); ?></h1>
        <div class="show-subtitle">
          Tipo: <?php echo e($operacion->tipo); ?> · Creada el <?php echo e($operacion->created_at->format('d/m/Y H:i')); ?>

        </div>
      </div>

      <div class="show-actions">
        <a href="<?php echo e(route($routePrefix . '.operaciones.traslados.hoja', $operacion)); ?>" class="btn btn-blue">
          🧾 Hoja
        </a>


        <?php if($operacion->archivo_excel_path): ?>
          <a href="<?php echo e(route($routePrefix . '.operaciones.traslados.archivo', $operacion)); ?>" target="_blank" rel="noopener" class="btn btn-white">
            📎 Ver Excel adjunto
          </a>
        <?php endif; ?>
      </div>
    </div>

    <?php if(session('ok')): ?>
      <div class="alert alert-ok">
        <?php echo e(session('ok')); ?>

      </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
      <div class="alert alert-error">
        <?php echo e(session('error')); ?>

      </div>
    <?php endif; ?>

    <div class="main-card">

      <div class="summary-box">
        <div class="summary-top">
          <div>
            <div class="route-line">
              <strong>Origen:</strong> <?php echo e(optional($operacion->bodegaOrigen)->nombre ?? '—'); ?>

              <span class="route-arrow">→</span>
              <strong>Destino:</strong> <?php echo e(optional($operacion->bodegaDestino)->nombre ?? '—'); ?>

            </div>

            <div class="meta-line">
              Creado por:
              <strong><?php echo e(optional($operacion->creador)->name ?? '—'); ?></strong>
              · <?php echo e($operacion->created_at->format('d/m/Y H:i')); ?>

            </div>
          </div>

          <span class="badge <?php echo e($badgeClass); ?>">
            <?php echo e($operacion->estado); ?>

          </span>
        </div>

        <?php if($operacion->observacion): ?>
          <div class="note-box">
            <strong>Observación:</strong> <?php echo e($operacion->observacion); ?>

          </div>
        <?php endif; ?>

        <?php if($operacion->estado === 'RECHAZADO' && $operacion->motivo_rechazo): ?>
          <div class="reject-box">
            <strong>Motivo de rechazo:</strong> <?php echo e($operacion->motivo_rechazo); ?>

          </div>
        <?php endif; ?>
      </div>

      <div class="section-title">
        <span>Productos solicitados</span>
        <span><?php echo e($operacion->detalles->count()); ?> producto(s)</span>
      </div>

      <div class="table-wrap">
        <table class="items-table">
          <thead>
            <tr>
              <th>Producto</th>
              <th style="width: 150px; text-align: right;">Cantidad</th>
            </tr>
          </thead>

          <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $operacion->detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <tr>
                <td>
                  <div class="product-code"><?php echo e($d->producto_codigo); ?></div>
                  <div class="product-name">
                    <?php echo e(optional($d->producto)->descripcion ?? optional($d->producto)->nombre ?? 'Producto sin nombre'); ?>

                  </div>
                </td>

                <td class="qty">
                  <?php echo e($d->cantidad); ?>

                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr>
                <td colspan="2" class="empty-products">
                  Esta solicitud no tiene productos asociados.
                </td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

      <?php if($puedeDecidir): ?>
        <div class="decision-box">
          <div class="decision-grid">

            <form method="POST" action="<?php echo e(route($routePrefix . '.operaciones.traslados.aprobar', $operacion)); ?>">
              <?php echo csrf_field(); ?>
              <button class="btn btn-green">
                ✅ Aprobar
              </button>
            </form>

            <form method="POST"
                  action="<?php echo e(route($routePrefix . '.operaciones.traslados.rechazar', $operacion)); ?>"
                  class="reject-form">
              <?php echo csrf_field(); ?>

              <input name="motivo_rechazo"
                     required
                     class="input"
                     placeholder="Motivo de rechazo...">

              <button class="btn btn-red">
                ❌ Rechazar
              </button>
            </form>

          </div>
        </div>
      <?php endif; ?>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make(auth()->user()->role_id == 1 ? 'layouts.admin' : 'layouts.operador', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\EDSONG-PC\OneDrive - Grupo Soluciones en Conectividad S.A,\Documentos\GitHub\Edson-REP\resources\views/admin/traslados/show.blade.php ENDPATH**/ ?>