<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['class' => '']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['class' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $logo = file_exists(public_path('img/logo1.png'))
        ? 'img/logo1.png'
        : (file_exists(public_path('img/logo.png')) ? 'img/logo.png' : null);
?>

<?php if($logo): ?>
    <img src="<?php echo e(asset($logo)); ?>" <?php echo e($attributes->merge(['class' => $class, 'alt' => 'Logo'])); ?>>
<?php else: ?>
    <div <?php echo e($attributes->merge(['class' => trim($class . ' flex items-center justify-center bg-blue-100 text-blue-700 font-bold')])); ?>>
        GNS
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\EDSONG-PC\OneDrive - Grupo Soluciones en Conectividad S.A,\Documentos\GitHub\Edson-REP\resources\views/components/logo-image.blade.php ENDPATH**/ ?>