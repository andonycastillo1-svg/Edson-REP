<?php $__env->startSection('no_nav'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php
  $puedeGestionarPdfsFirmados = \Illuminate\Support\Facades\Schema::hasTable('asignacion_inventario_archivos');

  $asignacionesPorColaborador = $asignacionesPorColaborador ?? collect();
  $movimientos = $movimientos ?? collect();
  $pdfsDevolucionFirmados = $pdfsDevolucionFirmados ?? collect();
  $puedeCrearAsignaciones = $puedeCrearAsignaciones ?? false;
  $puedeGestionarDevoluciones = $puedeGestionarDevoluciones ?? false;
  $puedeSubirEvidencias = $puedeSubirEvidencias ?? false;
?>

<style>
  .asg-page {
    min-height: 100vh;
    background: #f8fafc;
    padding: 28px 16px;
  }

  .asg-container {
    max-width: 1280px;
    margin: 0 auto;
  }

  .asg-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16px;
    margin-bottom: 18px;
  }

  .asg-title {
    margin: 0;
    font-size: 22px;
    font-weight: 700;
    color: #0f172a;
  }

  .asg-subtitle {
    margin: 4px 0 0;
    font-size: 13px;
    color: #64748b;
  }

  .asg-actions {
    display: flex;
    gap: 8px;
  }

  .asg-btn-primary,
  .asg-btn-secondary {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    height: 34px;
    padding: 0 14px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 600;
    text-decoration: none;
    border: 1px solid transparent;
  }

  .asg-btn-primary {
    background: #2563eb;
    color: #fff;
  }

  .asg-btn-primary:hover {
    background: #1d4ed8;
  }

  .asg-btn-secondary {
    background: #fff;
    color: #334155;
    border-color: #dbe3ea;
  }

  .asg-btn-secondary:hover {
    background: #f8fafc;
  }

  .asg-alert {
    margin-bottom: 14px;
    border-radius: 10px;
    padding: 10px 14px;
    font-size: 13px;
  }

  .asg-alert-success {
    border: 1px solid #bbf7d0;
    background: #f0fdf4;
    color: #166534;
  }

  .asg-alert-error {
    border: 1px solid #fecaca;
    background: #fef2f2;
    color: #991b1b;
  }

  .asg-panel {
    background: #fff;
    border: 1px solid #dbe3ea;
    border-radius: 14px;
    overflow: hidden;
    box-shadow: 0 1px 2px rgba(15, 23, 42, .04);
  }

  .asg-panel-title {
    padding: 12px 16px;
    background: #f8fafc;
    border-bottom: 1px solid #dbe3ea;
    font-size: 14px;
    font-weight: 700;
    color: #0f172a;
  }

  .asg-collab {
    border-bottom: 1px solid #eef2f7;
  }

  .asg-collab:last-child {
    border-bottom: none;
  }

  .asg-collab summary {
    list-style: none;
  }

  .asg-collab summary::-webkit-details-marker {
    display: none;
  }

  .asg-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 18px;
    min-height: 58px;
    padding: 10px 16px;
    cursor: pointer;
    background: #fff;
  }

  .asg-row:hover {
    background: #f8fafc;
  }

  .asg-left {
    display: flex;
    align-items: center;
    gap: 12px;
    min-width: 280px;
    flex: 1;
  }

  .asg-arrow {
    font-size: 12px;
    color: #94a3b8;
    transition: transform .15s ease;
  }

  .asg-collab[open] .asg-arrow {
    transform: rotate(90deg);
  }

  .asg-avatar {
    width: 32px;
    height: 32px;
    border-radius: 8px;
    background: #eff6ff;
    color: #1d4ed8;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 13px;
    font-weight: 700;
    flex: 0 0 auto;
  }

  .asg-name {
    margin: 0;
    font-size: 14px;
    font-weight: 700;
    color: #0f172a;
    line-height: 1.2;
  }

  .asg-code {
    margin: 3px 0 0;
    font-size: 12px;
    color: #64748b;
  }

  .asg-metrics {
    display: flex;
    align-items: center;
    gap: 22px;
    flex: 0 0 auto;
  }

  .asg-metric-label {
    display: block;
    font-size: 10px;
    color: #94a3b8;
    text-transform: uppercase;
    letter-spacing: .04em;
    line-height: 1;
  }

  .asg-metric-value {
    display: block;
    margin-top: 4px;
    font-size: 13px;
    font-weight: 700;
    color: #0f172a;
  }

  .asg-pill {
    display: inline-flex;
    margin-top: 4px;
    padding: 2px 9px;
    border-radius: 999px;
    background: #eff6ff;
    color: #1d4ed8;
    font-size: 12px;
    font-weight: 700;
  }

  .asg-detail-btn {
    border: 1px solid #dbe3ea;
    background: #fff;
    color: #334155;
    border-radius: 7px;
    padding: 6px 10px;
    font-size: 12px;
    font-weight: 700;
  }

  .asg-collab[open] .asg-detail-btn {
    background: #0f172a;
    color: #fff;
    border-color: #0f172a;
  }

  .asg-detail {
    background: #f8fafc;
    border-top: 1px solid #dbe3ea;
    padding: 14px;
  }

  .asg-mini-card {
    background: #fff;
    border: 1px solid #dbe3ea;
    border-radius: 10px;
    padding: 12px;
    margin-bottom: 12px;
  }

  .asg-mini-card form {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
  }

  .asg-mini-title {
    margin: 0;
    font-size: 13px;
    font-weight: 700;
    color: #0f172a;
  }

  .asg-mini-text {
    margin: 2px 0 0;
    font-size: 11px;
    color: #64748b;
  }

  .asg-input {
    height: 32px;
    border: 1px solid #cbd5e1;
    border-radius: 7px;
    padding: 0 10px;
    font-size: 12px;
    color: #334155;
    background: #fff;
  }

  .asg-input:focus {
    outline: 2px solid #dbeafe;
    border-color: #3b82f6;
  }

  .asg-btn-warning {
    height: 32px;
    border: 1px solid #fcd34d;
    background: #fffbeb;
    color: #92400e;
    border-radius: 7px;
    padding: 0 12px;
    font-size: 12px;
    font-weight: 700;
    cursor: pointer;
  }

  .asg-btn-warning:hover {
    background: #fef3c7;
  }

  .asg-table-wrap {
    background: #fff;
    border: 1px solid #dbe3ea;
    border-radius: 10px;
    overflow: hidden;
  }

  .asg-table-scroll {
    overflow-x: auto;
  }

  .asg-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 12px;
    min-width: 1080px;
  }

  .asg-table thead {
    background: #f8fafc;
    color: #64748b;
    text-transform: uppercase;
    font-size: 11px;
  }

  .asg-table th,
  .asg-table td {
    padding: 8px 10px;
    border-bottom: 1px solid #eef2f7;
    vertical-align: middle;
  }

  .asg-table th {
    text-align: left;
    font-weight: 700;
  }

  .asg-product {
    font-weight: 700;
    color: #0f172a;
  }

  .asg-product-code {
    margin-top: 2px;
    color: #64748b;
    font-size: 11px;
  }

  .asg-status {
    display: inline-flex;
    padding: 2px 8px;
    border-radius: 999px;
    font-size: 11px;
    font-weight: 700;
  }

  .asg-status-green {
    background: #ecfdf5;
    color: #047857;
  }

  .asg-status-amber {
    background: #fffbeb;
    color: #b45309;
  }

  .asg-status-red {
    background: #fef2f2;
    color: #b91c1c;
  }

  .asg-status-gray {
    background: #f1f5f9;
    color: #475569;
  }

  .asg-small-input {
    width: 56px;
    height: 28px;
    border: 1px solid #cbd5e1;
    border-radius: 7px;
    text-align: center;
    font-size: 12px;
  }

  .asg-pdf-btn {
    display: inline-flex;
    justify-content: center;
    align-items: center;
    height: 28px;
    padding: 0 10px;
    border-radius: 7px;
    background: #2563eb;
    color: #fff;
    text-decoration: none;
    font-size: 11px;
    font-weight: 700;
  }

  .asg-pdf-btn:hover {
    background: #1d4ed8;
  }

  .asg-upload-form {
    display: flex;
    flex-direction: column;
    gap: 4px;
  }

  .asg-upload-row {
    display: flex;
    gap: 6px;
    align-items: center;
  }

  .asg-file {
    width: 160px;
    font-size: 11px;
  }

  .asg-upload-btn {
    height: 28px;
    border: 1px solid #cbd5e1;
    background: #fff;
    border-radius: 7px;
    padding: 0 10px;
    font-size: 11px;
    font-weight: 700;
    cursor: pointer;
  }

  .asg-footer-actions {
    padding: 10px 12px;
    background: #f8fafc;
    border-top: 1px solid #dbe3ea;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
  }

  .asg-footer-title {
    margin: 0;
    font-size: 12px;
    font-weight: 700;
    color: #0f172a;
  }

  .asg-footer-text {
    margin: 2px 0 0;
    font-size: 11px;
    color: #64748b;
  }

  .asg-history {
    margin-top: 18px;
  }

  @media (max-width: 768px) {
    .asg-header,
    .asg-row,
    .asg-mini-card form,
    .asg-footer-actions {
      flex-direction: column;
      align-items: stretch;
    }

    .asg-actions,
    .asg-metrics {
      width: 100%;
      justify-content: space-between;
    }

    .asg-left {
      min-width: 0;
    }

    .asg-upload-row {
      flex-direction: column;
      align-items: stretch;
    }

    .asg-file {
      width: 100%;
      max-width: 100%;
    }
  }
</style>

<div class="asg-page">
  <div class="asg-container">
    <?php if (isset($component)) { $__componentOriginal907d7ba0ef057281d9e83257e5f04480 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal907d7ba0ef057281d9e83257e5f04480 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.internal-navigation','data' => ['backUrl' => route('dashboard')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('internal-navigation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['back-url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('dashboard'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal907d7ba0ef057281d9e83257e5f04480)): ?>
<?php $attributes = $__attributesOriginal907d7ba0ef057281d9e83257e5f04480; ?>
<?php unset($__attributesOriginal907d7ba0ef057281d9e83257e5f04480); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal907d7ba0ef057281d9e83257e5f04480)): ?>
<?php $component = $__componentOriginal907d7ba0ef057281d9e83257e5f04480; ?>
<?php unset($__componentOriginal907d7ba0ef057281d9e83257e5f04480); ?>
<?php endif; ?>

    <div class="asg-header">
      <div>
        <h1 class="asg-title">Mis asignaciones</h1>
        <p class="asg-subtitle">Control de equipos asignados, documentos firmados y devoluciones.</p>
      </div>

      <?php if($puedeCrearAsignaciones): ?>
        <div class="asg-actions">
          <a href="<?php echo e(route($routePrefix . '.asignaciones.create')); ?>" class="asg-btn-primary">
            + Nueva asignación
          </a>
        </div>
      <?php endif; ?>
    </div>

    <?php if(session('success')): ?>
      <div class="asg-alert asg-alert-success">
        <?php echo e(session('success')); ?>


        <?php if(session('grupo_devolucion')): ?>
          <div style="margin-top:6px;">
            <a href="<?php echo e(route($routePrefix . '.asignaciones.hoja_devolucion', session('grupo_devolucion'))); ?>"
               target="_blank"
               rel="noopener noreferrer"
               style="font-weight:700; text-decoration:underline;">
              Ver hoja de devolución
            </a>
          </div>
        <?php endif; ?>
      </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
      <div class="asg-alert asg-alert-error">
        <?php echo e(session('error')); ?>

      </div>
    <?php endif; ?>

    <div class="asg-panel">
      <div class="asg-panel-title">
        Colaboradores con asignaciones
      </div>

      <?php if(blank($asignacionesPorColaborador)): ?>
        <div style="padding:32px; text-align:center; color:#64748b;">
          No hay asignaciones disponibles para este usuario.
        </div>
      <?php else: ?>
        <?php foreach ($asignacionesPorColaborador as $grupo): ?>
          <?php
            $bulkFormId = 'bulk-return-' . $grupo['colaborador_codigo'];
          ?>

          <?php if($puedeGestionarDevoluciones): ?>
            <form id="<?php echo e($bulkFormId); ?>" method="POST" action="<?php echo e(route($routePrefix . '.asignaciones.devolver_lote')); ?>">
              <?php echo csrf_field(); ?>
            </form>
          <?php endif; ?>

          <details class="asg-collab">
            <summary>
              <div class="asg-row">
                <div class="asg-left">
                  <span class="asg-arrow">▶</span>

                  <div class="asg-avatar">
                    <?php echo e(strtoupper(mb_substr($grupo['colaborador_nombre'] ?? 'C', 0, 1))); ?>

                  </div>

                  <div>
                    <p class="asg-name"><?php echo e($grupo['colaborador_nombre']); ?></p>
                    <p class="asg-code">Código: <strong><?php echo e($grupo['colaborador_codigo']); ?></strong></p>
                  </div>
                </div>

                <div class="asg-metrics">
                  <div>
                    <span class="asg-metric-label">Asignaciones</span>
                    <span class="asg-metric-value"><?php echo e($grupo['asignaciones']->count()); ?></span>
                  </div>

                  <div>
                    <span class="asg-metric-label">Activas</span>
                    <span class="asg-pill"><?php echo e($grupo['total_activo']); ?></span>
                  </div>

                  <span class="asg-detail-btn">Ver detalle</span>
                </div>
              </div>
            </summary>

            <div class="asg-detail">

              <?php if($puedeGestionarDevoluciones): ?>
              <div class="asg-mini-card">
                <form method="POST"
                      action="<?php echo e(route($routePrefix . '.asignaciones.devolver_todo_colaborador', $grupo['colaborador_codigo'])); ?>">
                  <?php echo csrf_field(); ?>

                  <div>
                    <p class="asg-mini-title">Acciones del colaborador</p>
                    <p class="asg-mini-text">Puedes devolver todo lo activo o seleccionar productos específicos.</p>
                  </div>

                  <div style="display:flex; gap:8px; flex-wrap:wrap;">
                    <input type="text"
                           name="detalle_devolucion"
                           placeholder="Motivo devolución total"
                           class="asg-input"
                           style="width:260px;">

                    <button type="submit"
                            class="asg-btn-warning"
                            onclick="return confirm('¿Devolver todo lo activo de este colaborador?')">
                      Devolver todo
                    </button>
                  </div>
                </form>
              </div>
              <?php endif; ?>

              <div class="asg-table-wrap">
                <div class="asg-table-scroll">
                  <table class="asg-table">
                    <thead>
                      <tr>
                        <th>Sel.</th>
                        <th>Producto</th>
                        <th>Fecha</th>
                        <th>Bodega</th>
                        <th>Estado inventario</th>
                        <th>Entrega</th>
                        <th>Vida útil</th>
                        <th style="text-align:center;">Activa</th>
                        <th style="text-align:center;">Dev.</th>
                        <th style="text-align:center;">PDF</th>
                        <th>Evidencias</th>
                      </tr>
                    </thead>

                    <tbody>
                      <?php foreach ($grupo['asignaciones'] as $a): ?>
                        <?php
                          $estado = $a->estado ?? 'Activa';
                          $activa = $estado === 'Activa' && (int) $a->cantidad_asignada > 0;
                          $productoNombre = optional($a->producto)->descripcion ?? optional($a->producto)->nombre ?? $a->producto_codigo;

                          $fechaVenc = !empty($a->fecha_vencimiento)
                            ? \Carbon\Carbon::parse($a->fecha_vencimiento)
                            : null;

                          $pdfAsignacionFirmado = $puedeGestionarPdfsFirmados ? ($a->pdfAsignacionFirmado ?? null) : null;
                        ?>

                        <tr>
                          <td>
                            <?php if($activa && $puedeGestionarDevoluciones): ?>
                              <input type="checkbox"
                                     name="seleccionadas[]"
                                     value="<?php echo e($a->id); ?>"
                                     form="<?php echo e($bulkFormId); ?>"
                                     class="selector"
                                     data-target="devolucion_<?php echo e($a->id); ?>">
                            <?php else: ?>
                              —
                            <?php endif; ?>
                          </td>

                          <td>
                            <div class="asg-product"><?php echo e($productoNombre); ?></div>
                            <div class="asg-product-code">COD: <?php echo e($a->producto_codigo); ?></div>
                          </td>

                          <td>
                            <?php echo e($a->fecha ? date('d/m/Y', strtotime($a->fecha)) : '—'); ?>

                          </td>

                          <td>
                            <?php echo e(optional($a->bodega)->nombre ?? '—'); ?>

                          </td>

                          <td>
                            <?php if($estado === 'Activa'): ?>
                              <span class="asg-status asg-status-green">Activa</span>
                            <?php elseif($estado === 'Dañada'): ?>
                              <span class="asg-status asg-status-red">Dañada</span>
                            <?php else: ?>
                              <span class="asg-status asg-status-gray"><?php echo e($estado); ?></span>
                            <?php endif; ?>
                          </td>

                          <td>
                            <?php if(($a->estado_evidencia ?? 'completa') === 'completa'): ?>
                              <span class="asg-status asg-status-green">Completa</span>
                            <?php else: ?>
                              <span class="asg-status asg-status-amber">Pendiente</span>
                            <?php endif; ?>
                          </td>

                          <td>
                            <?php if($fechaVenc && $fechaVenc->isFuture()): ?>
                              <span class="asg-status asg-status-green">Dentro de vida útil</span>
                            <?php elseif($fechaVenc): ?>
                              <span class="asg-status asg-status-amber">Depreciado</span>
                            <?php else: ?>
                              <span style="color:#94a3b8;">Sin dato</span>
                            <?php endif; ?>
                          </td>

                          <td style="text-align:center; font-weight:700;">
                            <?php echo e($a->cantidad_asignada); ?>

                          </td>

                          <td style="text-align:center;">
                            <?php if($activa && $puedeGestionarDevoluciones): ?>
                              <input type="number"
                                     id="devolucion_<?php echo e($a->id); ?>"
                                     name="devoluciones[<?php echo e($a->id); ?>]"
                                     form="<?php echo e($bulkFormId); ?>"
                                     min="1"
                                     max="<?php echo e($a->cantidad_asignada); ?>"
                                     value="1"
                                     disabled
                                     class="asg-small-input">
                            <?php else: ?>
                              <span style="color:#94a3b8;">No aplica</span>
                            <?php endif; ?>
                          </td>

                          <td style="text-align:center;">
                            <?php if(!empty($a->grupo_asignacion)): ?>
                              <a href="<?php echo e(route($routePrefix . '.asignaciones.pdf', $a->grupo_asignacion)); ?>"
                                 target="_blank"
                                 rel="noopener noreferrer"
                                 class="asg-pdf-btn">
                                PDF
                              </a>
                            <?php else: ?>
                              <span style="color:#94a3b8;">Sin grupo</span>
                            <?php endif; ?>
                          </td>

                          <td>
                            <?php if($puedeSubirEvidencias): ?>
                              <form method="POST"
                                    action="<?php echo e(route($routePrefix . '.asignaciones.upload_pdf_firmado', $a)); ?>"
                                    enctype="multipart/form-data"
                                    class="asg-upload-form">
                                <?php echo csrf_field(); ?>
                                <div class="asg-upload-row">
                                  <input type="file"
                                         name="evidencias[]"
                                         accept="application/pdf,.pdf,image/jpeg,image/png,image/webp,.jpg,.jpeg,.png,.webp"
                                         multiple
                                         required
                                         class="asg-file">
                                  <button type="submit" class="asg-upload-btn">Subir</button>
                                </div>
                                <span style="font-size:11px; color:#64748b;">Requiere 1 PDF firmado y 1 imagen.</span>
                              </form>
                            <?php endif; ?>

                            <?php if($puedeGestionarPdfsFirmados): ?>
                              <div style="display:flex; flex-direction:column; gap:4px; margin-top:6px;">
                                <?php $__empty_1 = true; $__currentLoopData = $a->evidencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evidencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                  <a href="<?php echo e(route($routePrefix . '.asignaciones.ver_pdf_firmado', $evidencia)); ?>"
                                     target="_blank"
                                     rel="noopener noreferrer"
                                     style="font-size:11px; font-weight:700; color:<?php echo e($evidencia->tipo_documento === 'asignacion_firmada' ? '#047857' : '#1d4ed8'); ?>;">
                                    <?php echo e($evidencia->tipo_documento === 'asignacion_firmada' ? 'PDF' : 'Imagen'); ?>:
                                    <?php echo e($evidencia->nombre_original ?? 'Evidencia'); ?>

                                  </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                  <span style="font-size:11px; color:#94a3b8;">Sin evidencias</span>
                                <?php endif; ?>
                              </div>
                            <?php endif; ?>
                          </td>
                        </tr>
                      <?php endforeach; ?>
                    </tbody>
                  </table>
                </div>

                <?php if($puedeGestionarDevoluciones): ?>
                  <div class="asg-footer-actions">
                    <div>
                      <p class="asg-footer-title">Devolución de seleccionados</p>
                      <p class="asg-footer-text">Marca asignaciones y coloca la cantidad a devolver.</p>
                    </div>

                    <div style="display:flex; gap:8px; flex-wrap:wrap;">
                      <input type="text"
                             name="detalle_devolucion"
                             form="<?php echo e($bulkFormId); ?>"
                             placeholder="Detalle devolución múltiple"
                             class="asg-input"
                             style="width:260px;">

                      <button type="submit"
                              form="<?php echo e($bulkFormId); ?>"
                              class="asg-btn-warning">
                        Devolver seleccionados
                      </button>
                    </div>
                  </div>
                <?php endif; ?>
              </div>

            </div>
          </details>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>

    <?php if($puedeGestionarDevoluciones): ?>
    <div class="asg-panel asg-history">
      <div class="asg-panel-title">
        Historial de movimientos
      </div>

      <div class="asg-table-scroll">
        <table class="asg-table">
          <thead>
            <tr>
              <th>Fecha</th>
              <th>Tipo</th>
              <th>Colaborador</th>
              <th style="text-align:center;">Cantidad</th>
              <th>Detalle</th>
              <th>Usuario</th>
              <th style="text-align:center;">Documento</th>
            </tr>
          </thead>

          <tbody>
            <?php if(blank($movimientos)): ?>
              <tr>
                <td colspan="7" style="padding:28px; text-align:center; color:#64748b;">
                  Sin movimientos registrados.
                </td>
              </tr>
            <?php else: ?>
              <?php foreach ($movimientos as $m): ?>
                <?php
                  $pdfDevolucionFirmado = null;

                  if ($m->tipo === 'Devolucion' && !empty($m->grupo_devolucion) && $puedeGestionarPdfsFirmados) {
                    $pdfDevolucionFirmado = $pdfsDevolucionFirmados->get($m->grupo_devolucion);
                  }
                ?>

                <tr>
                  <td><?php echo e($m->created_at?->format('d/m/Y H:i')); ?></td>

                  <td>
                    <span class="asg-status asg-status-gray">
                      <?php echo e($m->tipo); ?>

                    </span>
                  </td>

                  <td>
                    <?php echo e(optional(optional($m->asignacion)->colaborador)->nombre ?? '—'); ?>

                  </td>

                  <td style="text-align:center; font-weight:700;">
                    <?php echo e($m->cantidad); ?>

                  </td>

                  <td>
                    <?php echo e($m->detalle ?? '—'); ?>

                  </td>

                  <td>
                    <?php echo e(optional($m->user)->name ?? '—'); ?>

                  </td>

                  <td style="text-align:center;">
                    <?php if($m->tipo === 'Devolucion' && !empty($m->grupo_devolucion)): ?>
                      <div class="asg-upload-form">
                        <a href="<?php echo e(route($routePrefix . '.asignaciones.hoja_devolucion', $m->grupo_devolucion)); ?>"
                           target="_blank"
                           rel="noopener noreferrer"
                           class="asg-pdf-btn">
                          Ver hoja
                        </a>

                        <form method="POST"
                              action="<?php echo e(route($routePrefix . '.asignaciones.upload_pdf_devolucion_firmado', $m->grupo_devolucion)); ?>"
                              enctype="multipart/form-data"
                              class="asg-upload-form">
                          <?php echo csrf_field(); ?>

                          <div class="asg-upload-row">
                            <input type="file"
                                   name="pdf_firmado"
                                   accept="application/pdf,.pdf"
                                   required
                                   class="asg-file">

                            <button type="submit" class="asg-upload-btn">
                              <?php echo e($pdfDevolucionFirmado ? 'Reemplazar firmado' : 'Subir firmado'); ?>

                            </button>
                          </div>
                        </form>

                        <?php if($pdfDevolucionFirmado): ?>
                          <a href="<?php echo e(route($routePrefix . '.asignaciones.ver_pdf_firmado', $pdfDevolucionFirmado)); ?>"
                             target="_blank"
                             rel="noopener noreferrer"
                             style="font-size:11px; font-weight:700; color:#047857;">
                            Ver firmado: <?php echo e($pdfDevolucionFirmado->nombre_original ?? 'PDF firmado'); ?>

                          </a>
                        <?php endif; ?>
                      </div>
                    <?php else: ?>
                      <span style="color:#94a3b8;">—</span>
                    <?php endif; ?>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
    <?php endif; ?>

  </div>
</div>

<script>
<?php if(session('pdf_url')): ?>
  window.addEventListener('load', function () {
    window.open(<?php echo json_encode(session('pdf_url'), 15, 512) ?>, '_blank', 'noopener,noreferrer');
  });
<?php endif; ?>
  document.querySelectorAll('.selector').forEach((checkbox) => {
    checkbox.addEventListener('change', function () {
      const targetId = this.dataset.target;
      const input = document.getElementById(targetId);

      if (!input) return;

      input.disabled = !this.checked;

      if (!this.checked) {
        input.value = 1;
      }
    });
  });

  document.querySelectorAll('form[id^="bulk-return-"]').forEach((form) => {
    form.addEventListener('submit', function (event) {
      const selected = document.querySelectorAll('[form="' + form.id + '"].selector:checked');

      if (!selected.length) {
        event.preventDefault();
        alert('Selecciona al menos una asignación para devolver.');
      }
    });
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\EDSONG-PC\OneDrive - Grupo Soluciones en Conectividad S.A,\Documentos\GitHub\Edson-REP\resources\views/admin/asignaciones/index.blade.php ENDPATH**/ ?>