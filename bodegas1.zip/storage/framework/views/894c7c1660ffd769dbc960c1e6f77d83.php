<?php $__env->startSection('content'); ?>
<div class="mx-auto w-full max-w-5xl px-4 py-8 sm:px-6 lg:px-8">
    <?php if (isset($component)) { $__componentOriginal907d7ba0ef057281d9e83257e5f04480 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal907d7ba0ef057281d9e83257e5f04480 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.internal-navigation','data' => ['backUrl' => route('dashboard')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('internal-navigation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['back-url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('dashboard'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal907d7ba0ef057281d9e83257e5f04480)): ?>
<?php $attributes = $__attributesOriginal907d7ba0ef057281d9e83257e5f04480; ?>
<?php unset($__attributesOriginal907d7ba0ef057281d9e83257e5f04480); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal907d7ba0ef057281d9e83257e5f04480)): ?>
<?php $component = $__componentOriginal907d7ba0ef057281d9e83257e5f04480; ?>
<?php unset($__componentOriginal907d7ba0ef057281d9e83257e5f04480); ?>
<?php endif; ?>

    <div class="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-xl shadow-slate-200/60">
        <div class="flex flex-col gap-4 border-b border-slate-200 bg-gradient-to-r from-white to-blue-50 px-5 py-6 sm:flex-row sm:items-center sm:justify-between sm:px-7">
            <div>
                <p class="text-xs font-extrabold uppercase tracking-[0.18em] text-blue-600">Centro de avisos</p>
                <h1 class="mt-1 text-2xl font-extrabold text-slate-950">Notificaciones</h1>
                <p class="mt-1 text-sm text-slate-500">Consulta y administra los avisos asociados a tu usuario.</p>
            </div>

            <div class="flex flex-wrap gap-2">
                <form method="POST" action="<?php echo e(route('notificaciones.leer-todas')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <button type="submit" class="inline-flex items-center justify-center rounded-xl border border-blue-200 bg-blue-50 px-4 py-2 text-sm font-semibold text-blue-700 transition hover:bg-blue-100">
                        Marcar todas como leídas
                    </button>
                </form>

                <form method="POST" action="<?php echo e(route('notificaciones.eliminar-todas')); ?>" onsubmit="return confirm('¿Eliminar todas tus notificaciones? Esta acción no se puede deshacer.');">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="inline-flex items-center justify-center rounded-xl border border-rose-200 bg-white px-4 py-2 text-sm font-semibold text-rose-700 transition hover:bg-rose-50">
                        Eliminar todas
                    </button>
                </form>
            </div>
        </div>

        <?php if(session('success')): ?>
            <div class="mx-5 mt-5 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm font-semibold text-emerald-700 sm:mx-7">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <div class="divide-y divide-slate-100">
            <?php $__empty_1 = true; $__currentLoopData = $notificaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notificacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $data = $notificacion->data;
                    $url = $data['url'] ?? null;
                    $urlSegura = is_string($url) && \Illuminate\Support\Str::startsWith($url, [url('/'), '/']);
                ?>

                <article class="px-5 py-5 sm:px-7 <?php echo e($notificacion->read_at ? 'bg-white' : 'bg-blue-50/60'); ?>">
                    <div class="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                        <div class="flex min-w-0 gap-3">
                            <span class="mt-2 h-3 w-3 shrink-0 rounded-full <?php echo e($notificacion->read_at ? 'bg-slate-300' : 'bg-blue-600'); ?>"></span>
                            <div class="min-w-0">
                                <div class="flex flex-wrap items-center gap-2">
                                    <h2 class="font-bold text-slate-900"><?php echo e($data['titulo'] ?? 'Notificación'); ?></h2>
                                    <span class="rounded-full px-2.5 py-1 text-[11px] font-bold <?php echo e($notificacion->read_at ? 'bg-slate-100 text-slate-600' : 'bg-blue-100 text-blue-700'); ?>">
                                        <?php echo e($notificacion->read_at ? 'Leída' : 'No leída'); ?>

                                    </span>
                                </div>

                                <p class="mt-2 text-sm leading-6 text-slate-600"><?php echo e($data['mensaje'] ?? ''); ?></p>

                                <div class="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-500">
                                    <span>Tipo: <?php echo e(str_replace('_', ' ', $data['tipo'] ?? 'general')); ?></span>
                                    <time datetime="<?php echo e($notificacion->created_at?->toIso8601String()); ?>">
                                        <?php echo e($notificacion->created_at?->format('d/m/Y H:i')); ?>

                                    </time>
                                </div>
                            </div>
                        </div>

                        <div class="flex shrink-0 flex-wrap items-center gap-2 sm:justify-end">
                            <?php if($urlSegura): ?>
                                <a href="<?php echo e($url); ?>" class="inline-flex items-center justify-center rounded-lg bg-blue-600 px-3 py-2 text-xs font-bold text-white transition hover:bg-blue-700">
                                    Abrir
                                </a>
                            <?php endif; ?>

                            <?php if(!$notificacion->read_at): ?>
                                <form method="POST" action="<?php echo e(route('notificaciones.leer', $notificacion->id)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <button type="submit" class="inline-flex items-center justify-center rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs font-bold text-slate-700 transition hover:bg-slate-50">
                                        Marcar como leída
                                    </button>
                                </form>
                            <?php endif; ?>

                            <form method="POST" action="<?php echo e(route('notificaciones.eliminar', $notificacion->id)); ?>" onsubmit="return confirm('¿Eliminar esta notificación?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="inline-flex items-center justify-center rounded-lg border border-rose-200 bg-white px-3 py-2 text-xs font-bold text-rose-700 transition hover:bg-rose-50">
                                    Eliminar
                                </button>
                            </form>
                        </div>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="px-6 py-16 text-center">
                    <div class="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-slate-100 text-2xl">🔔</div>
                    <p class="mt-4 font-semibold text-slate-700">No tienes notificaciones.</p>
                </div>
            <?php endif; ?>
        </div>

        <?php if($notificaciones->hasPages()): ?>
            <div class="border-t border-slate-200 bg-slate-50 px-5 py-4 sm:px-7">
                <?php echo e($notificaciones->links()); ?>

            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\EDSONG-PC\OneDrive - Grupo Soluciones en Conectividad S.A,\Documentos\GitHub\Edson-REP\resources\views/notificaciones/index.blade.php ENDPATH**/ ?>