<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title><?php echo $__env->yieldContent('title', 'Admin - Inventario'); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="ui-shell">

    <header class="ui-topbar">
        <div class="ui-topbar-inner">
            <div class="ui-brand">
                <img src="<?php echo e(asset('img/logo1.png')); ?>" alt="Logo" class="ui-brand-logo">
                <span class="ui-brand-name">Grupo NetSolutions</span>
            </div>

            <div class="flex items-center gap-2">
                <?php echo $__env->make('partials.notificaciones-campana', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php if (! (request()->routeIs('dashboard', '*.dashboard'))): ?>
                    <a href="<?php echo e(route('dashboard')); ?>"
                       class="hidden sm:inline-flex items-center justify-center rounded-full border border-emerald-200 bg-emerald-50 px-4 py-2 text-xs font-bold text-emerald-700 shadow-sm transition hover:bg-emerald-100">
                        Panel principal
                    </a>
                <?php endif; ?>

                <div class="inline-flex min-w-0 items-center gap-2 rounded-full border border-sky-200 bg-white px-3 py-1.5 text-sm font-semibold text-[#1F2937] md:text-base">
                    <span class="inline-flex h-6 w-6 items-center justify-center rounded-full bg-blue-100 text-blue-700">👤</span>
                    <span class="hidden max-w-[220px] truncate sm:block"><?php echo e(auth()->user()->name); ?></span>
                </div>
            </div>
        </div>
    </header>

    <?php if (! (request()->routeIs('dashboard', '*.dashboard'))): ?>
        <div class="mx-auto mt-4 w-full max-w-7xl px-4 md:hidden">
            <a href="<?php echo e(route('dashboard')); ?>"
               class="inline-flex w-full items-center justify-center rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-2 text-xs font-bold text-emerald-700 shadow-sm transition hover:bg-emerald-100">
                Panel principal
            </a>
        </div>
    <?php endif; ?>

    <main class="mx-auto min-h-[calc(100vh-64px)] w-full max-w-7xl px-4 py-8 md:px-6">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

</body>
</html>
<?php /**PATH C:\Users\EDSONG-PC\OneDrive - Grupo Soluciones en Conectividad S.A,\Documentos\GitHub\Edson-REP\resources\views/layouts/admin.blade.php ENDPATH**/ ?>