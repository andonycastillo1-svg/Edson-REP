<?php $__env->startSection('title', 'Login - Inventario'); ?>

<?php $__env->startSection('content'); ?>
<div class="ui-panel w-full max-w-md overflow-hidden">

    <!-- Header con logo -->
    <div class="border-b border-sky-100 bg-gradient-to-br from-white to-sky-50 px-8 py-8 text-center">
        <div class="mx-auto mb-5 flex h-28 w-48 items-center justify-center rounded-3xl border border-sky-100 bg-white p-4 shadow-sm">
            <?php if (isset($component)) { $__componentOriginal465f35e2d68cfdba82705526413dd984 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal465f35e2d68cfdba82705526413dd984 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.logo-image','data' => ['class' => 'max-h-20 w-auto']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('logo-image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'max-h-20 w-auto']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal465f35e2d68cfdba82705526413dd984)): ?>
<?php $attributes = $__attributesOriginal465f35e2d68cfdba82705526413dd984; ?>
<?php unset($__attributesOriginal465f35e2d68cfdba82705526413dd984); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal465f35e2d68cfdba82705526413dd984)): ?>
<?php $component = $__componentOriginal465f35e2d68cfdba82705526413dd984; ?>
<?php unset($__componentOriginal465f35e2d68cfdba82705526413dd984); ?>
<?php endif; ?>
        </div>
        <span class="ui-kicker">Sistema corporativo</span>
        <h2 class="mt-2 text-2xl font-extrabold text-slate-950">Iniciar sesión</h2>
        <p class="mt-1 text-sm font-medium text-slate-500">Accede al sistema de inventario</p>
    </div>

    <!-- Form -->
    <div class="px-8 py-8">
        <?php if(session('status')): ?>
            <div class="ui-alert-success">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="ui-alert-error">
                <ul class="list-disc pl-5">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($e); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('login')); ?>" class="space-y-5">
            <?php echo csrf_field(); ?>

            <div>
                <label for="email" class="ui-label">Email</label>
                <input id="email" name="email" type="email" value="<?php echo e(old('email')); ?>" required autofocus
                       class="ui-input mt-1">
            </div>

            <div>
                <label for="password" class="ui-label">Password</label>
                <input id="password" name="password" type="password" required
                       class="ui-input mt-1">
            </div>
            </div>

            <button type="submit" class="ui-btn-primary w-full">
                Ingresar
            </button>
        </form>
    </div>
</div>  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\EDSONG-PC\OneDrive - Grupo Soluciones en Conectividad S.A,\Documentos\GitHub\Edson-REP\resources\views/auth/login.blade.php ENDPATH**/ ?>