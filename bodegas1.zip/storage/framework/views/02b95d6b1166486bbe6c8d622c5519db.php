  

  <?php $__env->startSection('content'); ?>
  <?php
    $routePrefix = auth()->user()->role_id == 2 ? 'operador' : 'admin';
    $esOperador = auth()->user()->role_id == 2;
    $origenSeleccionado = old('bodega_origen_id', $origenId ?? ($esOperador ? auth()->user()->bodega_id : null));
  ?>

  <div class="min-h-[calc(100vh-120px)] px-6 py-10">
    <div class="max-w-4xl mx-auto">
      <?php if (isset($component)) { $__componentOriginal907d7ba0ef057281d9e83257e5f04480 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal907d7ba0ef057281d9e83257e5f04480 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.internal-navigation','data' => ['backUrl' => route($routePrefix . '.operaciones.traslados.index')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('internal-navigation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['back-url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route($routePrefix . '.operaciones.traslados.index'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal907d7ba0ef057281d9e83257e5f04480)): ?>
<?php $attributes = $__attributesOriginal907d7ba0ef057281d9e83257e5f04480; ?>
<?php unset($__attributesOriginal907d7ba0ef057281d9e83257e5f04480); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal907d7ba0ef057281d9e83257e5f04480)): ?>
<?php $component = $__componentOriginal907d7ba0ef057281d9e83257e5f04480; ?>
<?php unset($__componentOriginal907d7ba0ef057281d9e83257e5f04480); ?>
<?php endif; ?>

      <div class="mb-6">
        <h1 class="text-3xl font-bold text-slate-900 mt-2">Nueva solicitud de traslado</h1>
        <p class="text-sm text-slate-50000">El encargado de la bodega destino debe aprobar o rechazar.</p>
      </div>

      <?php if($errors->any()): ?>
        <div class="mb-5 rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-red-800">
          <div class="font-semibold mb-1">Revisa estos datos:</div>
          <ul class="list-disc ml-5 text-sm">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
      <?php endif; ?>

      <form method="POST" action="<?php echo e(route($routePrefix . '.operaciones.traslados.store')); ?>"
            enctype="multipart/form-data"
            class="rounded-2xl bg-white shadow-sm border border-slate-200 overflow-hidden">
        <?php echo csrf_field(); ?>

        <div class="px-6 py-4 border-b border-slate-100">
          <div class="text-sm font-semibold text-slate-800">Origen y destino</div>
          <div class="text-xs text-slate-500">Tip: si entraste desde bodegas, el origen viene precargado.</div>
        </div>

        <div class="p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label class="text-sm font-semibold text-slate-700">Bodega origen</label>

            <?php if($esOperador): ?>
              <input type="hidden" name="bodega_origen_id" value="<?php echo e(auth()->user()->bodega_id); ?>">
              <div class="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm bg-slate-100">
                <?php echo e(optional($bodegas->firstWhere('id', auth()->user()->bodega_id))->nombre); ?>

              </div>
            <?php else: ?>
              <select name="bodega_origen_id" required class="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm">
                <option value="">Selecciona...</option>
                <?php $__currentLoopData = $bodegas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($b->id); ?>"
                    <?php echo e((string) old('bodega_origen_id', $origenId) === (string) $b->id ? 'selected' : ''); ?>>
                    <?php echo e($b->nombre); ?>

                  </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            <?php endif; ?>
          </div>

          <div>
            <label class="text-sm font-semibold text-slate-700">Bodega destino</label>
            <select id="bodega_destino_id" name="bodega_destino_id" required class="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm">
              <option value="">Selecciona...</option>
              <?php $__currentLoopData = $bodegas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if((string)$b->id !== (string)$origenSeleccionado): ?>
                  <option value="<?php echo e($b->id); ?>" <?php echo e((string) old('bodega_destino_id') === (string) $b->id ? 'selected' : ''); ?>>
                    <?php echo e($b->nombre); ?>

                  </option>
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
        </div>

        <div class="px-6 pb-6">
          <label class="text-sm font-semibold text-slate-700">Observación (opcional)</label>
          <textarea name="observacion" rows="2"
            class="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm"
            placeholder="Ej: Enviar con guía #123, frágil, etc."><?php echo e(old('observacion')); ?></textarea>
        </div>

        <div class="px-6 pb-6">
          <label class="text-sm font-semibold text-slate-700">Excel de destinatarios (opcional)</label>
          <input type="file" name="archivo_excel" accept=".xlsx,.xls,.csv"
            class="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm bg-white">
          <p class="mt-1 text-xs text-slate-500">
            Puedes adjuntar un archivo .xlsx, .xls o .csv con las personas destinatarias de los productos trasladados.
          </p>
        </div>

        <div class="px-6 py-4 border-t border-b border-slate-100 flex items-center justify-between">
          <div>
            <div class="text-sm font-semibold text-slate-800">Productos</div>
            <div class="text-xs text-slate-500">Agrega una o varias líneas.</div>
          </div>
        </div>

        <div class="p-6">
          <div class="overflow-x-auto">
            <table class="w-full text-sm">
              <thead class="bg-slate-50 text-slate-600">
                <tr>
                  <th class="text-left px-3 py-2 font-semibold">Producto</th>
                  <th class="text-left px-3 py-2 font-semibold w-40">Cantidad</th>
                  <th class="px-3 py-2 w-20"></th>
                </tr>
              </thead>

              <tbody id="linesBody" class="divide-y divide-slate-100">
                <?php
                  $oldLines = old('lineas', [
                    ['producto_codigo' => '', 'cantidad' => 1],
                  ]);
                ?>

                <?php $__currentLoopData = $oldLines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr class="line-row">
                    <td class="px-3 py-3">
                      <select required
                              name="lineas[<?php echo e($i); ?>][producto_codigo]"
                              data-searchable="true"
                              data-search-placeholder="Buscar producto..."
                              class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm">
                        <option value="">Selecciona...</option>
                        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($p->codigo); ?>"
                            <?php echo e(($line['producto_codigo'] ?? '') === $p->codigo ? 'selected' : ''); ?>>
                            <?php echo e($p->descripcion ?: $p->nombre); ?> — <?php echo e($p->codigo); ?>

                          </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </td>

                    <td class="px-3 py-3">
                      <input type="number" min="1" required
                            name="lineas[<?php echo e($i); ?>][cantidad]"
                            value="<?php echo e($line['cantidad'] ?? 1); ?>"
                            class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm"/>
                    </td>

                    <td class="px-3 py-3 text-right">
                      <button type="button"
                              class="btnRemove inline-flex items-center justify-center rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50">
                        ✕
                      </button>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <tr class="bg-slate-50">
                  <td colspan="3" class="px-3 py-3">
                    <button type="button" id="btnAddLine"
                            class="inline-flex items-center gap-2 rounded-xl border border-blue-700 bg-blue-600 px-4 py-2 text-white text-sm font-semibold hover:bg-blue-700"
                            style="background-color:#2563eb;color:#fff;">
                      + Agregar línea
                    </button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <div class="px-6 py-4 border-t border-slate-100 flex items-center justify-end gap-2">
          <a href="<?php echo e(route($routePrefix . '.operaciones.traslados.index')); ?>"
            class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50">
            Cancelar
          </a>

          <button class="rounded-xl bg-blue-600 px-4 py-2 text-white text-sm font-semibold hover:bg-blue-700">
            Crear solicitud
          </button>
        </div>
      </form>

      <template id="lineTemplate">
        <tr class="line-row">
          <td class="px-3 py-3">
            <select required data-searchable="true" data-search-placeholder="Buscar producto..." class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm">
              <option value="">Selecciona...</option>
              <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($p->codigo); ?>"><?php echo e($p->descripcion ?: $p->nombre); ?> — <?php echo e($p->codigo); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </td>
          <td class="px-3 py-3">
            <input type="number" min="1" value="1" required class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm"/>
          </td>
          <td class="px-3 py-3 text-right">
            <button type="button" class="btnRemove inline-flex items-center justify-center rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50">
              ✕
            </button>
          </td>
        </tr>
      </template>

      <script>
        (function () {
          const body = document.getElementById('linesBody');
          const tpl  = document.getElementById('lineTemplate');
          const btn  = document.getElementById('btnAddLine');
          const origenSelect = document.querySelector('select[name=\"bodega_origen_id\"]');
          const destinoSelect = document.getElementById('bodega_destino_id');

          function reindex() {
            const rows = body.querySelectorAll('.line-row');
            rows.forEach((row, idx) => {
              const sel = row.querySelector('select');
              const inp = row.querySelector('input[type="number"]');
              sel.name = `lineas[${idx}][producto_codigo]`;
              inp.name = `lineas[${idx}][cantidad]`;
            });
          }

          function bindRemove(row) {
            row.querySelector('.btnRemove').addEventListener('click', () => {
              const rows = body.querySelectorAll('.line-row');
              if (rows.length <= 1) return;
              row.remove();
              reindex();
            });
          }

          body.querySelectorAll('.line-row').forEach(bindRemove);
          body.querySelectorAll('.line-row select[data-searchable="true"]').forEach((sel) => {
            if (window.enhanceSearchableSelect) window.enhanceSearchableSelect(sel);
          });

          btn.addEventListener('click', () => {
            const fragment = tpl.content.cloneNode(true);
            const row = fragment.querySelector('.line-row');

            const addRow = btn.closest('tr');
            addRow.parentNode.insertBefore(row, addRow);

            bindRemove(row);
            const productSelect = row.querySelector('select[data-searchable="true"]');
            if (productSelect && window.enhanceSearchableSelect) {
              window.enhanceSearchableSelect(productSelect);
            }
            reindex();
          });

          reindex();

          function syncDestinoOptions() {
            if (!origenSelect || !destinoSelect) return;
            const origenId = (origenSelect.value || '').toString();

            Array.from(destinoSelect.options).forEach((opt) => {
              if (!opt.value) return;
              opt.hidden = opt.value === origenId;
              opt.disabled = opt.value === origenId;
            });

            if (destinoSelect.value === origenId) {
              destinoSelect.value = '';
            }
          }

          if (origenSelect && destinoSelect) {
            origenSelect.addEventListener('change', syncDestinoOptions);
            syncDestinoOptions();
          }
        })();
      </script>

    </div>
  </div>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\EDSONG-PC\OneDrive - Grupo Soluciones en Conectividad S.A,\Documentos\GitHub\Edson-REP\resources\views/admin/traslados/create.blade.php ENDPATH**/ ?>