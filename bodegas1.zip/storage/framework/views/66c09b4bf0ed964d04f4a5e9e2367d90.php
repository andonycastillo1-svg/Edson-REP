<?php $__env->startSection('title', 'Crear usuario'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $routePrefix = auth()->user()->role_id == 4 ? 'rrhh' : 'admin';

    $rolSeleccionadoId = (int) old('role_id', 0);

    $mostrarBodega = $rolSeleccionadoId === (int) $rolAlmacenistaId;
    $mostrarAlmacenista = $rolSeleccionadoId === (int) $rolSupervisorId;
?>

<div class="w-full max-w-3xl bg-white/95 backdrop-blur rounded-2xl shadow-2xl p-6 md:p-8">
    <?php if (isset($component)) { $__componentOriginal907d7ba0ef057281d9e83257e5f04480 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal907d7ba0ef057281d9e83257e5f04480 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.internal-navigation','data' => ['backUrl' => route($routePrefix . '.usuarios.index')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('internal-navigation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['back-url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route($routePrefix . '.usuarios.index'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal907d7ba0ef057281d9e83257e5f04480)): ?>
<?php $attributes = $__attributesOriginal907d7ba0ef057281d9e83257e5f04480; ?>
<?php unset($__attributesOriginal907d7ba0ef057281d9e83257e5f04480); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal907d7ba0ef057281d9e83257e5f04480)): ?>
<?php $component = $__componentOriginal907d7ba0ef057281d9e83257e5f04480; ?>
<?php unset($__componentOriginal907d7ba0ef057281d9e83257e5f04480); ?>
<?php endif; ?>

    <div class="flex items-center justify-between mb-6">
        <div>
            <h1 class="text-2xl font-semibold text-gray-800">Crear usuario</h1>
            <p class="text-sm text-gray-500">Registra un nuevo usuario para el sistema</p>
        </div>
    </div>

    <?php if($errors->any()): ?>
        <div class="mb-6 rounded-xl bg-red-50 text-red-700 px-4 py-3 text-sm">
            <ul class="list-disc pl-5">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($e); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route($routePrefix . '.usuarios.store')); ?>" class="space-y-5">
        <?php echo csrf_field(); ?>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-5">

            <div>
                <label class="block text-sm font-medium text-gray-700">Nombre</label>
                <input type="text"
                       name="name"
                       value="<?php echo e(old('name')); ?>"
                       required
                       class="mt-1 w-full rounded-xl border-gray-300 focus:border-blue-500 focus:ring-blue-500">
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-700">Correo</label>
                <input type="email"
                       name="email"
                       value="<?php echo e(old('email')); ?>"
                       required
                       class="mt-1 w-full rounded-xl border-gray-300 focus:border-blue-500 focus:ring-blue-500">
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-700">Rol</label>

                <select name="role_id"
                        id="role_id"
                        required
                        class="mt-1 w-full rounded-xl border-gray-300 focus:border-blue-500 focus:ring-blue-500">

                    <?php if(auth()->user()->role_id != 4): ?>
                        <option value="">Seleccione...</option>
                    <?php endif; ?>

                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $tipoRol = 'otro';

                            if ((int) $rol->id === (int) $rolAlmacenistaId) {
                                $tipoRol = 'almacenista';
                            }

                            if ((int) $rol->id === (int) $rolSupervisorId) {
                                $tipoRol = 'supervisor';
                            }
                        ?>

                        <option value="<?php echo e($rol->id); ?>"
                                data-role-type="<?php echo e($tipoRol); ?>"
                                <?php echo e($rolSeleccionadoId === (int) $rol->id ? 'selected' : ''); ?>>
                            <?php echo e($rol->nombre); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <p class="text-xs text-gray-400 mt-1">
                    Define el acceso del usuario.
                </p>
            </div>

            <div id="bodega_wrap" class="<?php echo e($mostrarBodega ? '' : 'hidden'); ?>">
                <label class="block text-sm font-medium text-gray-700">Bodega</label>

                <select name="bodega_id"
                        id="bodega_id"
                        <?php echo e($mostrarBodega ? 'required' : 'disabled'); ?>

                        class="mt-1 w-full rounded-xl border-gray-300 focus:border-blue-500 focus:ring-blue-500">

                    <option value="">Seleccione...</option>

                    <?php $__currentLoopData = $bodegas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($b->id); ?>" <?php echo e(old('bodega_id') == $b->id ? 'selected' : ''); ?>>
                            <?php echo e($b->nombre); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <p class="text-xs text-gray-400 mt-1">
                    Asigna la bodega que administrará este usuario.
                </p>
            </div>

            <div id="almacenista_wrap" class="<?php echo e($mostrarAlmacenista ? '' : 'hidden'); ?>">
                <label class="block text-sm font-medium text-gray-700">Almacenista asignado</label>

                <select name="almacenista_id"
                        id="almacenista_id"
                        <?php echo e($mostrarAlmacenista ? 'required' : 'disabled'); ?>

                        class="mt-1 w-full rounded-xl border-gray-300 focus:border-blue-500 focus:ring-blue-500">

                    <option value="">Seleccione...</option>

                    <?php $__currentLoopData = $almacenistas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $almacenista): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($almacenista->id); ?>"
                                <?php echo e(old('almacenista_id') == $almacenista->id ? 'selected' : ''); ?>>
                            <?php echo e($almacenista->name); ?> (<?php echo e($almacenista->email); ?>)
                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <p class="text-xs text-gray-400 mt-1">
                    Selecciona el almacenista al que pertenece este supervisor.
                </p>
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-700">Contraseña</label>
                <input type="password"
                       name="password"
                       required
                       class="mt-1 w-full rounded-xl border-gray-300 focus:border-blue-500 focus:ring-blue-500">
            </div>

            <div class="md:col-span-2">
                <label class="block text-sm font-medium text-gray-700">Confirmar contraseña</label>
                <input type="password"
                       name="password_confirmation"
                       required
                       class="mt-1 w-full rounded-xl border-gray-300 focus:border-blue-500 focus:ring-blue-500">
            </div>
        </div>

        <div class="pt-4 border-t flex flex-col sm:flex-row gap-3 justify-end">
            <a href="<?php echo e(route($routePrefix . '.usuarios.index')); ?>"
               class="inline-flex items-center justify-center rounded-xl border border-gray-200 bg-white px-5 py-2.5 text-gray-700 font-semibold hover:bg-gray-50 transition">
                Cancelar
            </a>

            <button type="submit"
                    class="inline-flex items-center justify-center rounded-xl bg-blue-600 px-5 py-2.5 text-white font-semibold shadow hover:bg-blue-700 transition">
                Guardar
            </button>
        </div>
    </form>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const rolSelect = document.getElementById('role_id');

    const bodegaWrap = document.getElementById('bodega_wrap');
    const bodegaSelect = document.getElementById('bodega_id');

    const almacenistaWrap = document.getElementById('almacenista_wrap');
    const almacenistaSelect = document.getElementById('almacenista_id');

    function actualizarCamposPorRol() {
        if (!rolSelect) {
            return;
        }

        const selectedOption = rolSelect.options[rolSelect.selectedIndex];
        const tipoRol = selectedOption ? selectedOption.dataset.roleType : 'otro';

        const esAlmacenista = tipoRol === 'almacenista';
        const esSupervisor = tipoRol === 'supervisor';

        if (bodegaWrap && bodegaSelect) {
            bodegaWrap.classList.toggle('hidden', !esAlmacenista);
            bodegaSelect.disabled = !esAlmacenista;
            bodegaSelect.required = esAlmacenista;

            if (!esAlmacenista) {
                bodegaSelect.value = '';
            }
        }

        if (almacenistaWrap && almacenistaSelect) {
            almacenistaWrap.classList.toggle('hidden', !esSupervisor);
            almacenistaSelect.disabled = !esSupervisor;
            almacenistaSelect.required = esSupervisor;

            if (!esSupervisor) {
                almacenistaSelect.value = '';
            }
        }
    }

    if (rolSelect) {
        rolSelect.addEventListener('change', actualizarCamposPorRol);
        actualizarCamposPorRol();
    }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\EDSONG-PC\OneDrive - Grupo Soluciones en Conectividad S.A,\Documentos\GitHub\Edson-REP\resources\views/admin/usuarios/create.blade.php ENDPATH**/ ?>