<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AlertaReemplazo extends Model
{
    public const ESTADO_PENDIENTE = 'pendiente';
    public const ESTADO_FINALIZADO = 'finalizado';

    protected $table = 'alertas_reemplazos_rrhh';

    protected $fillable = [
        'colaborador_codigo',
        'producto_codigo',
        'vehiculo_vin',
        'vehiculo_producto_asignacion_id',
        'cantidad',
        'costo_estimado',
        'registrado_por_user_id',
        'asignacion_anterior_id',
        'asignacion_nueva_id',
        'fecha_asignacion_anterior',
        'fecha_dano_reemplazo',
        'vida_util_meses',
        'meses_restantes',
        'descuento_aplicable',
        'estado',
        'detalle',
    ];

    protected $casts = [
        'fecha_asignacion_anterior' => 'datetime',
        'fecha_dano_reemplazo' => 'datetime',
        'descuento_aplicable' => 'boolean',
    ];

    public function estaPendiente(): bool
    {
        return ($this->estado ?? self::ESTADO_PENDIENTE) === self::ESTADO_PENDIENTE;
    }

    public function marcarFinalizada(): void
    {
        $this->forceFill([
            'estado' => self::ESTADO_FINALIZADO,
        ])->save();
    }
}
